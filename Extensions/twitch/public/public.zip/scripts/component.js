const VIEW_TYPE = "component";

function is_mobile() {
	return false;
}

function is_component() {
	return true;

}