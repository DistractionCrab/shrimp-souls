import { Root } from "./init.js";
import { MESSAGES } from "../messages.js";

const PAGEINFO = `
Where would you like to go?
<ul>
	<li>
		<button>To the Arena!</button>
	</li>
</ul>
`;


class Hub extends Root {
	update(data) {

	}
}