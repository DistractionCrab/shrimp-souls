const VIEW_TYPE = "mobile";

function is_mobile() {
	return true;
}

function is_component() {
	return false;
}